// ==========================================================
// INICJALIZACJA I OBSŁUGA BAZY DANYCH (IndexedDB)
// ==========================================================
let db;
const request = indexedDB.open("WorkoutAppDB", 2);

request.onupgradeneeded = (event) => {
    db = event.target.result;
    if (!db.objectStoreNames.contains("profiles")) {
        db.createObjectStore("profiles", { keyPath: "id" });
    }
};

request.onsuccess = (event) => {
    db = event.target.result;
    initApp(); // <-- NA TO
};

async function initApp() {
    await checkAuth();
    console.log("Aplikacja gotowa");
}

request.onerror = (event) => {
    console.error("Błąd bazy danych IndexedDB:", event.target.error);
};

// ==========================================================
// ZMIENNE GLOBALNE
// ==========================================================
let currentProfile = null;
let currentDayIndex = null;
let currentExerciseIndex = null;
let currentSet = 1;
let timerInterval = null;
let timeLeft = 0;
let totalTimerDuration = 0;

// Ekrany
const screenAuth = document.getElementById("screenAuth");
const screenMain = document.getElementById("screenMain");
const screenExercise = document.getElementById("screenExercise");
const screenTimer = document.getElementById("screenTimer");
const screenFinish = document.getElementById("screenFinish");

// Elementy
const authUsername = document.getElementById("authUsername");
const loginBtn = document.getElementById("loginBtn");
const profileNameSpan = document.getElementById("profileName");
const logoutBtn = document.getElementById("logoutBtn");
const deleteAccountBtn = document.getElementById("deleteAccountBtn");
const daysContainer = document.getElementById("daysContainer");

const exerciseName = document.getElementById("exerciseName");
const exerciseCounter = document.getElementById("exerciseCounter");
const progressFill = document.getElementById("progressFill");
const infoSets = document.getElementById("infoSets");
const infoReps = document.getElementById("infoReps");
const infoWeight = document.getElementById("infoWeight");
const btnPrevExercise = document.getElementById("btnPrevExercise");
const btnDeleteExercise = document.getElementById("btnDeleteExercise");
const btnNextSet = document.getElementById("btnNextSet");
const btnSkipExercise = document.getElementById("btnSkipExercise");

const timerText = document.getElementById("timerText");
const timerProgressCircle = document.getElementById("timerProgressCircle");
const nextExName = document.getElementById("nextExName");
const nextExSets = document.getElementById("nextExSets");
const btnSkipTimer = document.getElementById("btnSkipTimer");
const btnAdd15s = document.getElementById("btnAdd15s");
const btnBackToMain = document.getElementById("btnBackToMain");
const modalOverlay = document.getElementById("modalOverlay");
const modalContentArea = document.getElementById("modalContentArea");

// ==========================================================
// FUNKCJE POMOCNICZE (Modale)
// ==========================================================
function showModal(htmlContent) {
    modalContentArea.innerHTML = htmlContent;
    modalOverlay.classList.add("active");
}

function closeModal() {
    modalOverlay.classList.remove("active");
    modalContentArea.innerHTML = "";
}

function customPrompt(title, labelText, defaultValue = "") {
    return new Promise((resolve) => {
        const html = `<h3>${title}</h3><div class="input-group"><label>${labelText}</label><input type="text" id="promptInput" value="${defaultValue}"></div><div class="modal-buttons"><button class="modal-btn secondary" id="promptCancel">Anuluj</button><button class="modal-btn primary" id="promptOk">Zatwierdź</button></div>`;
        showModal(html);
        const input = document.getElementById("promptInput");
        input.focus();
        document.getElementById("promptOk").onclick = () => { closeModal(); resolve(input.value.trim() || null); };
        document.getElementById("promptCancel").onclick = () => { closeModal(); resolve(null); };
    });
}

function customConfirm(title, message, isDanger = false) {
    return new Promise((resolve) => {
        const html = `<h3>${title}</h3><p>${message}</p><div class="modal-buttons"><button class="modal-btn secondary" id="confirmCancel">Anuluj</button><button class="modal-btn ${isDanger ? 'danger' : 'primary'}" id="confirmOk">Potwierdź</button></div>`;
        showModal(html);
        document.getElementById("confirmOk").onclick = () => { closeModal(); resolve(true); };
        document.getElementById("confirmCancel").onclick = () => { closeModal(); resolve(false); };
    });
}

// ==========================================================
// EDYCJA PARAMETRÓW (NOWA LOGIKA)
// ==========================================================
async function editField(field, label) {
    const ex = currentProfile.days[currentDayIndex].exercises[currentExerciseIndex];
    const val = await customPrompt(`Edytuj ${label}`, `Wpisz nową wartość:`, String(ex[field]));
    if (val !== null) {
        ex[field] = (field === 'sets') ? (parseInt(val, 10) || 1) : val;
        await saveProfileToDB(currentProfile);
        loadExercise();
    }
}

// Podpięcie zdarzeń edycji
infoSets.onclick = () => editField('sets', 'serii');
infoReps.onclick = () => editField('reps', 'powtórzeń');
infoWeight.onclick = () => editField('weight', 'ciężaru (kg)');
exerciseName.onclick = () => editField('name', 'nazwy');

// ==========================================================
// LOGIKA TRENINGU
// ==========================================================
function loadExercise() {
    const ex = currentProfile.days[currentDayIndex].exercises[currentExerciseIndex];
    exerciseCounter.textContent = `${currentExerciseIndex + 1} z ${currentProfile.days[currentDayIndex].exercises.length}`;
    exerciseName.textContent = ex.name;
    infoSets.querySelector("strong").textContent = `${currentSet} z ${ex.sets}`;
    
    const repsArr = ex.reps.split(",");
    const weightArr = ex.weight.split(",");
    infoReps.querySelector("strong").textContent = repsArr[currentSet - 1] || repsArr[0];
    infoWeight.querySelector("strong").textContent = (weightArr[currentSet - 1] || weightArr[0]) + " kg";
    
    btnNextSet.textContent = (currentSet < ex.sets) ? `Ukończ Serię ${currentSet}` : "Dalej";
}

function startWorkout(dayIndex) {
    currentDayIndex = dayIndex;
    currentExerciseIndex = 0;
    currentSet = 1;
    showScreen(screenExercise);
    loadExercise();
}

btnNextSet.onclick = () => {
    const ex = currentProfile.days[currentDayIndex].exercises[currentExerciseIndex];
    if (currentSet < ex.sets) {
        currentSet++;
        startTimer(180);
    } else if (currentExerciseIndex < currentProfile.days[currentDayIndex].exercises.length - 1) {
        currentExerciseIndex++;
        currentSet = 1;
        startTimer(300);
    } else {
        finishWorkoutAndSave();
    }
};

// ==========================================================
// FUNKCJE BAZOWE (Reszta pozostaje bez zmian)
// ==========================================================


// (Reszta funkcji: checkAuth, renderDashboard, startTimer, itp. pozostaje taka sama jak w Twoim oryginale)

// ==========================================================
// UWIERZYTELNIANIE I ZAPISYWANIE PROFILU
// ==========================================================
async function checkAuth() {
const loggedUserId = localStorage.getItem("loggedUserId");
if (loggedUserId) {
const profile = await getProfileFromDB(loggedUserId);
if (profile) {
currentProfile = profile;
showScreen(screenMain);
renderDashboard();
return;
}
}
showScreen(screenAuth);
}

// Ta jedna funkcja zastępuje obie poprzednie
function showScreen(targetScreen) {
    // 1. ZŁAP WINOWAJCĘ: Wyświetl w konsoli stos wywołań
    console.trace("Ktoś przełącza ekran na: " + (targetScreen ? targetScreen.id : "null"));

    const screens = [
        document.getElementById("screenAuth"),
        document.getElementById("screenMain"),
        document.getElementById("screenStats"),
        document.getElementById("screenExercise"),
        document.getElementById("screenTimer"),
        document.getElementById("screenFinish")
    ];

    screens.forEach(s => {
        if (s) s.classList.remove("active");
    });

    if (targetScreen) {
        targetScreen.classList.add("active");
    }
}
function getProfileFromDB(id) {
return new Promise((resolve) => {
const transaction = db.transaction(["profiles"], "readonly");
const store = transaction.objectStore("profiles");
const request = store.get(id);
request.onsuccess = () => resolve(request.result || null);
request.onerror = () => resolve(null);
});
}

function saveProfileToDB(profile) {
return new Promise((resolve) => {
const transaction = db.transaction(["profiles"], "readwrite");
const store = transaction.objectStore("profiles");
const request = store.put(profile);
request.onsuccess = () => resolve(true);
request.onerror = () => resolve(false);
});
}

function deleteProfileFromDB(id) {
return new Promise((resolve) => {
const transaction = db.transaction(["profiles"], "readwrite");
const store = transaction.objectStore("profiles");
const request = store.delete(id);
request.onsuccess = () => resolve(true);
request.onerror = () => resolve(false);
});
}

// Logowanie / Tworzenie nowego konta z AUTOMATYCZNYM PLANEM STARTOWYM
loginBtn.onclick = async () => {
const username = authUsername.value.trim();
if (!username) return;

const profileId = username.toLowerCase();
let profile = await getProfileFromDB(profileId);

// Jeśli profil nie istnieje, tworzymy go z Twoim domyślnym planem treningowym!
if (!profile) {
profile = {
id: profileId,
name: username,
days: [
{
name: "Dzień 1",
description: "Klatka, Biceps, Triceps, Barki",
exercises: [
// --- KLATKA ---
{
name: "Wyciskanie hantli na ławce poziomej",
category: "Klatka piersiowa",
sets: 4,
reps: "12,12,12,12",
weight: "10,10,10,10"
},
{
name: "Wyciskanie hantli na ławce skośnej dodatniej",
category: "Klatka piersiowa",
sets: 4,
reps: "10,10,10,10",
weight: "10,10,10,10"
},
{
name: "Rozpiętki z hantlami na ławce poziomej",
category: "Klatka piersiowa",
sets: 3,
reps: "10,10,10",
weight: "6,6,6"
},
{
name: "Pompki klasyczne",
category: "Klatka piersiowa",
sets: 3,
reps: "Max,Max,Max",
weight: "0,0,0" // własny ciężar ciała
},
// --- BICEPS ---
{
name: "Uginanie ramion z hantlami stojąc",
category: "Biceps",
sets: 4,
reps: "12,12,12,12",
weight: "10,10,10,10"
},
{
name: "Uginanie młotkowe",
category: "Biceps",
sets: 3,
reps: "10,10,10",
weight: "8,8,8"
},
{
name: "Uginanie na ławce skośnej",
category: "Biceps",
sets: 3,
reps: "10,10,10",
weight: "6,8,10"
},
// --- TRICEPS ---
{
name: "Wyciskanie francuskie hantla oburącz",
category: "Triceps",
sets: 4,
reps: "10,10,10,10",
weight: "12,12,12,12"
},
{
name: "Prostowanie ramienia z hantlem nad głową",
category: "Triceps",
sets: 3,
reps: "12,12,12",
weight: "8,8,8"
},
{
name: "Pompki na ławkach (bench dips)",
category: "Triceps",
sets: 3,
reps: "Max,Max,Max",
weight: "0,0,0"
},
// --- BARKI ---
{
name: "Wyciskanie hantli nad głowę siedząc",
category: "Barki",
sets: 4,
reps: "10,10,10,10",
weight: "10,10,10,10"
},
{
name: "Unoszenie hantli bokiem",
category: "Barki",
sets: 3,
reps: "12,12,12",
weight: "6,6,6"
},
{
name: "Unoszenie hantli w opadzie",
category: "Barki",
sets: 3,
reps: "12,12,12",
weight: "6,6,6"
}
]
},
{
name: "Dzień 2",
description: "Plecy, Nogi, Przedramiona",
exercises: [
// --- PLECY ---
{
name: "Wiosłowanie hantlami na ławce skośnej",
category: "Plecy",
sets: 4,
reps: "10,10,10,10",
weight: "12,12,12,12"
},
{
name: "Wiosłowanie jednorącz hantlem",
category: "Plecy",
sets: 4,
reps: "10,10,10,10",
weight: "14,14,14,14"
},
{
name: "Martwy ciąg rumuński z hantlami",
category: "Plecy",
sets: 3,
reps: "10,10,10",
weight: "16,16,16"
},
{
name: "Szrugsy z hantlami",
category: "Plecy",
sets: 4,
reps: "12,12,12,12",
weight: "16,16,16,16"
},
// --- NOGI ---
{
name: "Przysiady / Goblet squat z hantlem",
category: "Nogi",
sets: 5,
reps: "8,8,8,8,8",
weight: "16,16,16,16,16"
},
// --- PRZEDRAMIONA ---
{
name: "Uginanie nadgarstków z hantlami",
category: "Przedramiona",
sets: 4,
reps: "15,15,15,15",
weight: "6,6,6,6"
},
{
name: "Odwrotne uginanie nadgarstków",
category: "Przedramiona",
sets: 4,
reps: "15,15,15,15",
weight: "4,4,4,4"
},
{
name: "Spacer farmera z hantlami",
category: "Przedramiona",
sets: 3,
reps: "45s,45s,45s",
weight: "16,16,16"
}
]
}
]
};
await saveProfileToDB(profile);
}

currentProfile = profile;
localStorage.setItem("loggedUserId", profileId);
authUsername.value = "";
showScreen(screenMain);
renderDashboard();
};

// Wylogowanie
logoutBtn.onclick = () => {
localStorage.removeItem("loggedUserId");
currentProfile = null;
daysContainer.innerHTML = "";
showScreen(screenAuth);
};

// Całkowite usunięcie aktualnego profilu
deleteAccountBtn.onclick = async () => {
if (!currentProfile) return;

const confirmed = await customConfirm(
"Usuń profil",
`Czy na pewno chcesz bezpowrotnie usunąć swój profil "${currentProfile.name}" oraz wszystkie powiązane z nim treningi?`,
true
);

if (confirmed) {
await deleteProfileFromDB(currentProfile.id);
localStorage.removeItem("loggedUserId");
currentProfile = null;
daysContainer.innerHTML = "";
showScreen(screenAuth);
}
};


// ==========================================================
// RENDEROWANIE EKRANU GŁÓWNEGO (DASHBOARD)
// ==========================================================
function renderDashboard() {
if (!currentProfile) return;
profileNameSpan.textContent = currentProfile.name;
daysContainer.innerHTML = "";

currentProfile.days.forEach((day, index) => {
const card = document.createElement("div");
card.className = "dayCard";

const exercisesNames = day.exercises.map(e => e.name).join(", ") || "Brak ćwiczeń";
const shortDescription = day.description || exercisesNames;

card.innerHTML = `
<div class="dayHeader">
<div class="dayTitleArea">
<span class="subtitle">Plan Treningowy</span>
<h2>${day.name}</h2>
<span class="daySubtitle">${shortDescription}</span>
</div>
<div class="dayManageActions" onclick="event.stopPropagation();">
<button class="addExerciseButton" title="Dodaj nowe ćwiczenie" onclick="addNewExercise(${index})">+</button>
<button class="deleteDayButton" title="Usuń dzień treningowy" onclick="deleteDay(${index})">🗑</button>
</div>
</div>
<div class="dayFooter">
<span class="exerciseCountBadge">${day.exercises.length} ćwiczeń</span>
<button class="startButton" onclick="event.stopPropagation(); startWorkout(${index});">Rozpocznij</button>
</div>
`;

card.onclick = () => editDayInfo(index);
daysContainer.appendChild(card);
});

const addCard = document.createElement("div");
addCard.className = "dayCard addDayCard";
addCard.innerHTML = `
<div class="addDayContent">
<span class="addDayIcon">+</span>
<span class="addDayText">Dodaj nowy dzień</span>
</div>
`;
addCard.onclick = addNewDay;
daysContainer.appendChild(addCard);
}


// ==========================================================
// ZARZĄDZANIE PLANEM (DNI I ĆWICZENIA)
// ==========================================================

// Dodanie nowego dnia
async function addNewDay() {
const name = await customPrompt("Nowy dzień", "Nazwa dnia (np. Dzień 3):", `Dzień ${currentProfile.days.length + 1}`);
if (!name) return;

const description = await customPrompt("Nowy dzień", "Partie mięśniowe (np. Klatka, Plecy):", "Ogólny trening");
if (!description) return;

currentProfile.days.push({
name: name,
description: description,
exercises: []
});

await saveProfileToDB(currentProfile);
renderDashboard();
}

// Edycja nagłówka dnia
async function editDayInfo(dayIndex) {
const day = currentProfile.days[dayIndex];
const newName = await customPrompt("Edytuj dzień", "Nazwa dnia treningowego:", day.name);
if (!newName) return;

const newDesc = await customPrompt("Edytuj dzień", "Partie mięśniowe / Opis:", day.description);
if (!newDesc) return;

day.name = newName;
day.description = newDesc;

await saveProfileToDB(currentProfile);
renderDashboard();
}

// Usuwanie dnia
async function deleteDay(dayIndex) {
const day = currentProfile.days[dayIndex];
const confirmed = await customConfirm(
"Usuń dzień",
`Czy na pewno chcesz usunąć dzień treningowy "${day.name}" i wszystkie zaplanowane w nim ćwiczenia?`,
true
);

if (confirmed) {
currentProfile.days.splice(dayIndex, 1);
await saveProfileToDB(currentProfile);
renderDashboard();
}
}

// Szybkie ręczne dodawanie nowego ćwiczenia (gdyby użytkownik chciał coś sam dopisać)
async function addNewExercise(dayIndex) {
const name = await customPrompt("Dodaj ćwiczenie", "Wpisz nazwę nowego ćwiczenia:");
if (!name) return;

const category = await customPrompt("Dodaj ćwiczenie", "Kategoria / Partia mięśniowa (np. Klatka, Plecy):", "Inne");
if (!category) return;

const setsStr = await customPrompt("Dodaj ćwiczenie", "Liczba serii:", "4");
if (!setsStr) return;
const sets = parseInt(setsStr, 10) || 4;

const reps = await customPrompt(
"Dodaj ćwiczenie",
"Powtórzenia w seriach (oddzielone przecinkami):",
"12,10,8,6"
);
if (!reps) return;

const weight = await customPrompt(
"Dodaj ćwiczenie",
"Ciężar w seriach w kg (oddzielony przecinkami):",
"20,25,30,35"
);
if (!weight) return;

currentProfile.days[dayIndex].exercises.push({
name: name,
category: category,
sets: sets,
reps: reps,
weight: weight
});

await saveProfileToDB(currentProfile);
renderDashboard();
}


// ==========================================================
// PRZEBIEG TRENINGU (EKRAN ĆWICZEŃ)
// ==========================================================
function startWorkout(dayIndex) {
const day = currentProfile.days[dayIndex];
if (!day || day.exercises.length === 0) {
alert("Dodaj najpierw ćwiczenia do tego dnia!");
return;
}
currentDayIndex = dayIndex;
currentExerciseIndex = 0;
currentSet = 1;
showScreen(screenExercise);
loadExercise();
}

function loadExercise() {
const day = currentProfile.days[currentDayIndex];
const ex = day.exercises[currentExerciseIndex];

// Nagłówek i licznik ćwiczeń
exerciseCounter.textContent = `${currentExerciseIndex + 1} z ${day.exercises.length}`;
progressFill.style.width = `${((currentExerciseIndex + 1) / day.exercises.length) * 100}%`;

// Informacje o ćwiczeniu
document.querySelector(".exerciseCategory").textContent = ex.category || "Ćwiczenie";
exerciseName.textContent = ex.name;

// Aktualna seria
infoSets.querySelector("strong").textContent = `${currentSet} z ${ex.sets}`;

// Parsowanie powtórzeń i ciężaru
const repsArr = ex.reps.split(",");
const weightArr = ex.weight.split(",");

const currentReps = repsArr[currentSet - 1] || repsArr[repsArr.length - 1] || "10";
const currentWeight = weightArr[currentSet - 1] || weightArr[weightArr.length - 1] || "0";

infoReps.querySelector("strong").textContent = currentReps;
infoWeight.querySelector("strong").textContent = `${currentWeight} kg`;

btnPrevExercise.style.visibility = (currentExerciseIndex === 0 && currentSet === 1) ? "hidden" : "visible";

// Dynamiczny tekst na przycisku
if (currentSet < ex.sets) {
btnNextSet.textContent = `Ukończ Serię ${currentSet}`;
} else {
btnNextSet.textContent = (currentExerciseIndex < day.exercises.length - 1) ? "Przejdź do przerwy" : "Zakończ trening";
}
}

// Szybka edycja parametrów w trakcie treningu
exerciseName.onclick = async () => {
const day = currentProfile.days[currentDayIndex];
const ex = day.exercises[currentExerciseIndex];

const newName = await customPrompt("Edytuj ćwiczenie", "Nazwa:", ex.name);
if (!newName) return;

const newSets = await customPrompt("Edytuj ćwiczenie", "Liczba serii:", ex.sets.toString());
if (!newSets) return;

const newReps = await customPrompt("Edytuj ćwiczenie", "Powtórzenia w seriach (oddzielone przecinkami):", ex.reps);
if (!newReps) return;

const newWeight = await customPrompt("Edytuj ćwiczenie", "Ciężar w seriach (oddzielony przecinkami):", ex.weight);
if (!newWeight) return;

ex.name = newName;
ex.sets = parseInt(newSets, 10) || 4;
ex.reps = newReps;
ex.weight = newWeight;

await saveProfileToDB(currentProfile);
currentSet = 1;
loadExercise();
};

infoSets.onclick = () => exerciseName.click();
infoReps.onclick = () => exerciseName.click();
infoWeight.onclick = () => exerciseName.click();

// Usuwanie ćwiczenia podczas treningu
btnDeleteExercise.onclick = async () => {
const day = currentProfile.days[currentDayIndex];
const ex = day.exercises[currentExerciseIndex];

const confirmed = await customConfirm(
"Usuń ćwiczenie",
`Czy chcesz trwale usunąć ćwiczenie "${ex.name}" z tego planu?`,
true
);

if (confirmed) {
day.exercises.splice(currentExerciseIndex, 1);
await saveProfileToDB(currentProfile);

if (day.exercises.length === 0) {
showScreen(screenMain);
renderDashboard();
} else {
if (currentExerciseIndex >= day.exercises.length) {
currentExerciseIndex = day.exercises.length - 1;
}
currentSet = 1;
loadExercise();
}
}
};

// Następna seria / Następne ćwiczenie (z automatycznym czasem przerw)
btnNextSet.onclick = () => {
const day = currentProfile.days[currentDayIndex];
const ex = day.exercises[currentExerciseIndex];

if (currentSet < ex.sets) {
// Ta sama partia/ćwiczenie, kolejna seria -> AUTOMATYCZNIE 3 MINUTY (180s)
currentSet++;
startTimer(180);
} else {
if (currentExerciseIndex < day.exercises.length - 1) {
// Nowe ćwiczenie / nowa partia -> AUTOMATYCZNIE 5 MINUT (300s)
currentExerciseIndex++;
currentSet = 1;
startTimer(300);
} else {
finishWorkoutAndSave();
}
}
};

// Pominięcie ćwiczenia
btnSkipExercise.onclick = () => {
const day = currentProfile.days[currentDayIndex];
if (currentExerciseIndex < day.exercises.length - 1) {
currentExerciseIndex++;
currentSet = 1;
loadExercise();
} else {
finishWorkoutAndSave();
}
};

// Poprzednie ćwiczenie / Poprzednia seria
btnPrevExercise.onclick = () => {
if (currentSet > 1) {
currentSet--;
loadExercise();
} else if (currentExerciseIndex > 0) {
currentExerciseIndex--;
const prevEx = currentProfile.days[currentDayIndex].exercises[currentExerciseIndex];
currentSet = prevEx.sets;
loadExercise();
}
};


// ==========================================================
// SYSTEM TIMERA (PRZERWA MIĘDZY SERIAMI)
// ==========================================================
function startTimer(seconds) {
showScreen(screenTimer);
clearInterval(timerInterval);

timeLeft = seconds;
totalTimerDuration = seconds;
updateTimerDisplay();

const day = currentProfile.days[currentDayIndex];
const currentEx = day.exercises[currentExerciseIndex];

nextExName.textContent = currentEx.name;
nextExSets.textContent = `Seria ${currentSet} z ${currentEx.sets}`;
document.querySelector(".nextExercisePreview small").textContent = currentEx.category || "ĆWICZENIE";

timerInterval = setInterval(() => {
timeLeft--;
updateTimerDisplay();

if (timeLeft <= 0) {
clearInterval(timerInterval);
finishTimer();
}
}, 1000);
}

function updateTimerDisplay() {
const minutes = Math.floor(timeLeft / 60);
const seconds = timeLeft % 60;
timerText.textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

const maxOffset = 534;
const progress = timeLeft / totalTimerDuration;
const offset = maxOffset - (progress * maxOffset);
timerProgressCircle.style.strokeDashoffset = isNaN(offset) ? 0 : offset;
}

function finishTimer() {
clearInterval(timerInterval);
showScreen(screenExercise);
loadExercise();
}

// Dodanie 15 sekund
btnAdd15s.onclick = () => {
timeLeft += 15;
totalTimerDuration += 15;
updateTimerDisplay();
};

// Pominięcie odliczania
btnSkipTimer.onclick = () => {
finishTimer();
};


// ==========================================================
// EKRAN KOŃCOWY (FINISH)
// ==========================================================
// Czekamy, aż cała strona się załaduje
window.addEventListener('load', () => {
    const btn = document.getElementById("btnBackToMain");
    if (btn) {
        btn.onclick = () => {
            showScreen(screenMain);
            renderDashboard();
        };
    }

    // Dodaj to samo dla przycisku w statystykach, skoro używasz też ID: btnBackToMainFromStats
    const btnStats = document.getElementById("btnBackToMainFromStats");
    if (btnStats) {
        btnStats.onclick = () => {
            showScreen(screenMain);
            renderDashboard();
        };
    }
});

document.getElementById("showStatsBtn").onclick = async (event) => {
    event.preventDefault();
    event.stopPropagation(); // Kluczowe: zapobiega "bąbelkowaniu" zdarzenia
    
    console.log("Kliknięto przycisk statystyk!");
    const statsScreen = document.getElementById("screenStats");
    
    if (!statsScreen) return;

    // Najpierw ukrywamy wszystko, co główne, w sposób czysty
    showScreen(statsScreen);
    
    // Krótkie opóźnienie, aby DOM zdążył przełączyć ekrany
    await new Promise(r => setTimeout(r, 100));
    
    if (typeof renderStats === 'function') {
        await renderStats();
    }
};

async function finishWorkoutAndSave() {
    const day = currentProfile.days[currentDayIndex];
    
    // Przekazujemy tablicę ćwiczeń z bieżącego dnia do funkcji logWorkoutToHistory.
    // Funkcja ta automatycznie rozdzieli wyniki na kategorie i zapisze je w historii.
    if (day && day.exercises && day.exercises.length > 0) {
        await logWorkoutToHistory(day.exercises);
    }

    // Przechodzimy do ekranu końcowego
    showScreen(screenFinish);
}
