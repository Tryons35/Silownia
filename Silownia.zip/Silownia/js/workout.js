const workouts = [

    {
        id: 1,

        title: "Dzień 1",

        subtitle: "Klatka • Biceps • Triceps • Barki",

        exercises: [

            {
                category: "Klatka piersiowa",

                name: "Wyciskanie hantli na ławce poziomej",

                sets: 4,

                reps: "6–10",

                weight: "10kg ×12",

                media: ""
            },

            {
                category: "Klatka piersiowa",

                name: "Wyciskanie hantli na ławce skośnej dodatniej",

                sets: 4,

                reps: "8–12",

                weight: "10kg ×10",

                media: ""
            },

            {
                category: "Klatka piersiowa",

                name: "Rozpiętki z hantlami",

                sets: 3,

                reps: "10–15",

                weight: "6kg ×10",

                media: ""
            },

            {
                category: "Klatka piersiowa",

                name: "Pompki",

                sets: 3,

                reps: "Do upadku",

                weight: "-",

                media: ""
            },



            {
                category: "Biceps",

                name: "Uginanie ramion z hantlami",

                sets: 4,

                reps: "8–12",

                weight: "10kg ×12",

                media: ""
            },

            {
                category: "Biceps",

                name: "Uginanie młotkowe",

                sets: 3,

                reps: "10–12",

                weight: "8kg ×10",

                media: ""
            },

            {
                category: "Biceps",

                name: "Uginanie na ławce skośnej",

                sets: 3,

                reps: "10–12",

                weight: "6-10kg ×10",

                media: ""
            },



            {
                category: "Triceps",

                name: "Wyciskanie francuskie hantla oburącz",

                sets: 4,

                reps: "8–12",

                weight: "-",

                media: ""
            },

            {
                category: "Triceps",

                name: "Prostowanie ramienia nad głową",

                sets: 3,

                reps: "10–12",

                weight: "-",

                media: ""
            },

            {
                category: "Triceps",

                name: "Bench dips",

                sets: 3,

                reps: "Do upadku",

                weight: "-",

                media: ""
            },



            {
                category: "Barki",

                name: "Wyciskanie hantli siedząc",

                sets: 4,

                reps: "8–12",

                weight: "10kg ×10",

                media: ""
            },

            {
                category: "Barki",

                name: "Unoszenie bokiem",

                sets: 3,

                reps: "12–15",

                weight: "-",

                media: ""
            },

            {
                category: "Barki",

                name: "Unoszenie w opadzie",

                sets: 3,

                reps: "12–15",

                weight: "-",

                media: ""
            }

        ]
    },









    {
        id: 2,

        title: "Dzień 2",

        subtitle: "Plecy • Nogi • Przedramiona",

        exercises: [

            {
                category: "Plecy",

                name: "Wiosłowanie hantli na ławce skośnej",

                sets: 4,

                reps: "8–12",

                weight: "-",

                media: ""
            },

            {
                category: "Plecy",

                name: "Wiosłowanie jednorącz",

                sets: 4,

                reps: "8–12",

                weight: "-",

                media: ""
            },

            {
                category: "Plecy",

                name: "Martwy ciąg rumuński",

                sets: 3,

                reps: "8–10",

                weight: "-",

                media: ""
            },

            {
                category: "Plecy",

                name: "Szrugsy",

                sets: 4,

                reps: "10–15",

                weight: "-",

                media: ""
            },



            {
                category: "Nogi",

                name: "Goblet Squat",

                sets: 5,

                reps: "6–10",

                weight: "-",

                media: ""
            },



            {
                category: "Przedramiona",

                name: "Uginanie nadgarstków",

                sets: 4,

                reps: "15–20",

                weight: "-",

                media: ""
            },

            {
                category: "Przedramiona",

                name: "Odwrotne uginanie nadgarstków",

                sets: 4,

                reps: "15–20",

                weight: "-",

                media: ""
            },

            {
                category: "Przedramiona",

                name: "Spacer farmera",

                sets: 3,

                reps: "30–60 s",

                weight: "-",

                media: ""
            }

        ]
    }

];