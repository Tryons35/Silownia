let myChart = null;


// ==========================================================
// GŁÓWNE STATYSTYKI
// ==========================================================

async function renderStats() {
    const container = document.getElementById("statsContent");
    if (!container) return;

    if (!currentProfile.history || currentProfile.history.length === 0) {
        container.innerHTML = "<p style='text-align:center; padding: 20px; color: #666;'>Brak danych historycznych.</p>";
        return;
    }

    const months = [...new Set(currentProfile.history.map(e => e.date))].sort().reverse();
    
    // Główny kontener z ładnym paddingiem
    let html = `<div style="max-width: 600px; margin: 0 auto;">`;
    html += `<h2 style="font-size: 1.5rem; margin-bottom: 20px; color: #fff; font-weight: 600;">Historia treningów</h2>`;
    
    months.forEach(month => {
        html += `
            <div style="background: #1a1a1a; border-radius: 16px; padding: 20px; margin-bottom: 20px; border: 1px solid #333;">
                <h3 style="margin: 0 0 15px 0; font-size: 1.1rem; color: #3b82f6; text-transform: uppercase; letter-spacing: 1px;">
                    ${formatMonth(month)}
                </h3>
                <div style="display: grid; gap: 10px;">`;
        
        const monthData = currentProfile.history.filter(e => e.date === month);
        const categories = [...new Set(monthData.map(e => e.category))];
        
        categories.forEach(cat => {
            const startEntry = monthData.find(e => e.category === cat && e.type === "Start");
            html += `
                <div style="display: flex; justify-content: space-between; align-items: center; background: #252525; padding: 12px 15px; border-radius: 10px;">
                    <span style="color: #ddd; font-weight: 500;">${cat}</span>
                    <span style="background: #000; padding: 4px 10px; border-radius: 6px; color: #fff; font-family: monospace; font-size: 1.05rem;">
                        ${startEntry ? startEntry.weight + " <small style='color:#666; font-size:0.75rem;'>kg</small>" : "---"}
                    </span>
                </div>`;
        });
        
        html += `</div></div>`;
    });
    
    html += `</div>`; // zamkniecie głównego kontenera
    container.innerHTML = html;
}



// ==========================================================
// HISTORIA - TYLKO STARE MIESIĄCE
// ==========================================================


function renderHistoryList(months,lastMonth){


    const container =
        document.getElementById(
            "statsHistoryContainer"
        );


    if(!container) return;



    const historyMonths =
        months
        .filter(
            month =>
            month !== lastMonth
        )
        .reverse();



    if(historyMonths.length===0){

        container.innerHTML=`

        <h3>Historia</h3>

        <p style="color:#666">
        Brak zakończonych miesięcy.
        </p>

        `;

        return;

    }



    let html=`

    <h3>
    Historia (${historyMonths.length} mies.)
    </h3>

    `;



    historyMonths.forEach(
        (month,index)=>{


        const monthData =
            currentProfile.history.filter(
                e=>e.date===month
            );



        const summary={};



        monthData.forEach(e=>{


            if(!summary[e.category]){

                summary[e.category]={
                    sum:0,
                    count:0
                };

            }


            summary[e.category].sum += Number(e.weight);

            summary[e.category].count++;


        });



        html+=`

        <div class="history-month-card">


            <div class="history-header"
            onclick="toggleHistory(${index})">


                <span class="month-label">

                ${formatMonth(month)}

                </span>


                <span>

                ▼

                </span>


            </div>



            <div id="history-${index}"
            style="display:none">


            <ul class="history-list">

        `;



        for(let cat in summary){


            const avg =
            summary[cat].sum /
            summary[cat].count;



            html+=`

            <li>

            <span class="cat-name">

            ${cat}

            </span>


            <span class="cat-weight">

            ${avg.toFixed(1)} kg

            </span>


            </li>

            `;

        }



        html+=`

            </ul>

            </div>


        </div>

        `;


    });



    container.innerHTML=html;


}



// ==========================================================
// ROZWIJANIE HISTORII
// ==========================================================


function toggleHistory(id){


    const box =
    document.getElementById(
        "history-"+id
    );


    if(!box)return;



    if(box.style.display==="none"){

        box.style.display="block";

    }else{

        box.style.display="none";

    }

}



// ==========================================================
// FORMATOWANIE MIESIĘCY
// ==========================================================


function formatMonth(date){


    const parts =
    date.split("-");


    const year =
    parts[0];


    const month =
    Number(parts[1]);



    const names=[

        "Styczeń",
        "Luty",
        "Marzec",
        "Kwiecień",
        "Maj",
        "Czerwiec",
        "Lipiec",
        "Sierpień",
        "Wrzesień",
        "Październik",
        "Listopad",
        "Grudzień"

    ];



    return `${names[month-1]} ${year}`;

}



// ==========================================================
// ZAPIS TRENINGU DO HISTORII
// ==========================================================


async function logWorkoutToHistory(exercises) {
    if (!currentProfile.history) currentProfile.history = [];

    const now = new Date();
    const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

    exercises.forEach(ex => {
        // 1. Zamieniamy ciąg na tablicę liczb i usuwamy zera (dla ćwiczeń typu "własny ciężar")
        const weights = ex.weight.split(",").map(Number);
        const validWeights = weights.filter(w => w > 0);
        
        // Jeśli ćwiczenie ma same zera, przyjmujemy 0, w przeciwnym razie liczymy średnią
        const avg = validWeights.length > 0 
            ? (validWeights.reduce((a, b) => a + b, 0) / validWeights.length) 
            : 0;
        
        const cat = ex.category || "Inne";

        // Sprawdzamy czy "Start" już istnieje w tym miesiącu dla tej kategorii
        const hasStart = currentProfile.history.some(e => 
            e.date === currentMonth && e.category === cat && e.type === "Start"
        );

        // Zapisujemy średnią
        currentProfile.history.push({
            date: currentMonth,
            category: cat,
            weight: avg.toFixed(1), // Zapisuje średnią zaokrągloną do 1 miejsca
            type: hasStart ? "Trening" : "Start"
        });
    });

    await saveProfileToDB(currentProfile);
}



// ==========================================================
// RESET HISTORII
// ==========================================================


async function resetWorkoutHistory(){


    if(confirm(
        "Czy na pewno chcesz wyzerować wszystkie statystyki?"
    )){


        currentProfile.history=[];


        await saveProfileToDB(
            currentProfile
        );


        await renderStats();


    }


}

// ==========================================================
// GŁÓWNE STATYSTYKI
// ==========================================================
async function renderStats() {
    const container = document.getElementById("statsContent");
    if (!container) return;

    if (!currentProfile.history || currentProfile.history.length === 0) {
        container.innerHTML = "<p>Brak danych. Ukończ trening!</p>";
        return;
    }

    const months = [...new Set(currentProfile.history.map(e => e.date))].sort().reverse();
    let html = `<h2>Historia treningów</h2>`;
    
    months.forEach(month => {
        html += `<h3>${formatMonth(month)}</h3>`;
        const monthData = currentProfile.history.filter(e => e.date === month);
        const categories = [...new Set(monthData.map(e => e.category))];
        
        categories.forEach(cat => {
            // Szukamy wpisu typu "Start" dla tej kategorii
            const startEntry = monthData.find(e => e.category === cat && e.type === "Start");
            html += `
                <div style="display:flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #444;">
                    <span>${cat}</span>
                    <strong>Start: ${startEntry ? startEntry.weight + " kg" : "Brak"}</strong>
                </div>`;
        });
    });
    container.innerHTML = html;
}

// ==========================================================
// FORMATOWANIE MIESIĘCY
// ==========================================================
function formatMonth(date) {
    const parts = date.split("-");
    const names = ["Styczeń", "Luty", "Marzec", "Kwiecień", "Maj", "Czerwiec", "Lipiec", "Sierpień", "Wrzesień", "Październik", "Listopad", "Grudzień"];
    return `${names[Number(parts[1]) - 1]} ${parts[0]}`;
}

// ==========================================================
// ZAPIS TRENINGU DO HISTORII (Naprawiona logika sumowania)
// ==========================================================
async function logWorkoutToHistory(exercises) {
    if (!currentProfile.history) currentProfile.history = [];
    const now = new Date();
    const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

    // 1. Grupowanie wszystkich wag w ramach kategorii z całego treningu
    const categoryStats = {};

    exercises.forEach(ex => {
        const weights = ex.weight.split(",").map(Number).filter(w => w > 0);
        const cat = ex.category || "Inne";
        
        if (!categoryStats[cat]) categoryStats[cat] = { sum: 0, count: 0 };
        
        weights.forEach(w => {
            categoryStats[cat].sum += w;
            categoryStats[cat].count++;
        });
    });

    // 2. Zapisywanie średniej dla każdej kategorii (tylko 1 wpis na kategorię na trening)
    for (const cat in categoryStats) {
        const stats = categoryStats[cat];
        if (stats.count === 0) continue;
        
        const avg = stats.sum / stats.count;

        const hasStart = currentProfile.history.some(e => 
            e.date === currentMonth && e.category === cat && e.type === "Start"
        );

        currentProfile.history.push({
            date: currentMonth,
            category: cat,
            weight: avg.toFixed(1),
            type: hasStart ? "Trening" : "Start"
        });
    }

    await saveProfileToDB(currentProfile);
}
